"""AIOS CLI."""
